import { Text, View } from "react-native";

export const Register = () => (
    <View>
        <Text>Aqui é o Register</Text>
    </View>
)
