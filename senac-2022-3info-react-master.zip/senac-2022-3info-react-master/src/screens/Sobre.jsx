import { Text, View } from "react-native";

export const Sobre = () => (
    <View>
        <Text>Aqui é o sobre</Text>
    </View>
)
